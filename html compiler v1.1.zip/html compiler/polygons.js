// Import
let polygons = document.getElementById('polygons');
let new_polygon = document.getElementById('new_polygon');
let organisms = document.getElementById('organisms');
let outputs = document.getElementById('outputs');
// Important Variables
// If New Polygon Turn = 0 = True Else If New Polygon Turn = 1 = False
let polygon_turn = 0;

// New Polygon Button
let n = 0;
new_polygon.onclick = function()
{
    // On(Show)
    if(polygon_turn == 0)
    {
        polygons.style.display = 'inline-block';
        polygon_turn++;
    }
    // Off(Hide)
    else{
        polygons.style.display = 'none'; 
        polygon_turn--;     
    }
}
// Options
// Frist : Organisms
// Onchange Function
function return_image(id,)
{
    let label = document.getElementById(`btn_for_upload_image${n}`);  
    let div = document.getElementById(`upload_image_div${n}`);
    let file_element = document.getElementById(id);
    let img_id = `uploaded_image_organisms${n}`; 
    let img = document.getElementById(img_id);
    if(img.src == '')
    {
        let file = new FileReader;
        file.readAsDataURL(file_element.files[0]);
        file.onload = function(){
            img.src = file.result;
        }
        n += 1;
        label.innerText = 'Delete';
        label.for = 'None';
        label.onclick = () =>{
            div.innerHTML = '';
            n -= 1;
        }
    }

}
organisms.onclick = () =>
{
    // Body.Inner HTML
    document.body.innerHTML =
    `<button onclick="location.reload();" style="color:#fff;background:transparent;margin:20px;">close</button>
    <h3 style="text-align:center;">Text</h3>
    <p contenteditable="true" style="outline:none;background:#222;margin:auto;width:50%;"></p>
    <h3 style="text-align:center;">Image</h3>
    <!-- Image Organisms Button -->
    <button id="image_organisms" style="position:absolute;left:45%;text-align:center;background-color:#000;border:none;width:10%;font-size:200%;">+</button>
    <br>
    <br>
    <div id="image_organisms_div"></div>
    <h3 style="margin:25vh 0;text-align:center;">Video</h3>
    <!-- Video Organisms Button -->
    <button id="video_organisms" style="position:absolute;left:45%;margin:-20vh 0px;text-align:center;background-color:#000;border:none;width:10%;font-size:200%;">+</button>
    `;
    // Import From Body New Element
    let image_organisms = document.getElementById('image_organisms');
    let image_organisms_div = document.getElementById('image_organisms_div');
    let video_organisms = document.getElementById('video_organisms');
    // Image Orgaisms.Onclick 
    image_organisms.onclick = () =>
    {
        image_organisms_div.innerHTML += 
        `
        <div id="upload_image_div${n}" style="text-align:center;width:100%;margin:3% 0px;">
        <label for="upload_image_organisms${n}" id="btn_for_upload_image${n}" style="max-width:250px;text-align:center;color:#FFF;background-color:#222;padding:20px;width:100%;margin:10vh auto;height:20px;">upload</label>
        <input onchange="return_image(this.id)" type="file" id="upload_image_organisms${n}" style="display:none;"/>
        <br>
        <br>
        <img id="uploaded_image_organisms${n}" style="max-width:250px;margin:7.5% auto;"/>
        <br>
        <br>
        <p contenteditable="true" style="display:inline-block;outline:none;max-width:250px;overflow:auto;text-align:center;margin:auto;">Description</p>
        </div>
        `;
        image_organisms_div.style.cssText = `
        display:grid;
        gap:5px;
        overflow:auto;
        `;
        //Upload Image
    }
}

