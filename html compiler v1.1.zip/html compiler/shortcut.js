// Turn Show Double To Double The Charter
let Turn_Show_Double = 0;
// Command Prameter To Know Charcter = CTRL + / OR NO  
editor.addEventListener('keydown',function(command){
if(command.ctrlKey && command.key === 'c')
{
    editor.innerText += '<!---->';
}
});

editor.addEventListener('keydown',function(new_html){
    if(new_html.ctrlKey && new_html.shiftKey && new_html.key === '!')
    {
        new_html.preventDefault();
        editor.innerText += 
`<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <body>
    
    </body>
</html>`;
    }
});
document.addEventListener('keydown',function(Double){
    if(Double.ctrlKey && Double.shiftKey && Double.key === '*')
    {
        if(Turn_Show_Double == 0)
        {
            document.body.innerHTML += 
            `<div id="Double">
            <input type="text" id="Code_Category_To_Double" placeholder="code"/>
            <br>
            <input type="number" id="Double_The_Code_From_Code_Category_To_Double" placeholder="count"/>
            <br>
            <button>New Elements</button>
        </div>`;
            Turn_Show_Double++;
        }
        else if(Turn_Show_Double == 1)
        {
            let Double_div = document.getElementById('Double');
            Double_div.style.display = 'none';
            Turn_Show_Double--; 
        }
        let Code_Category_To_Double = document.getElementById('Code_Category_To_Double');
        let Double_The_Code_From_Code_Category_To_Double = document.getElementById('Double_The_Code_From_Code_Category_To_Double');
        
    }
});
 