let editor = document.getElementById('editor');
let run = document.getElementById('run');
let output = document.getElementById('output');
console.log(auto_save);
console.log(auto_save_img);
let auto_save_onclick = 0;
run.onclick = function()
{
 output.innerHTML = editor.innerText; 
 auto_save_img.src = 'auto save.png';
 editor.onkeyup = editor_false;
 auto_save_onclick = 1;
}

function editor_true()
{
    output.innerHTML = editor.innerText;    
}
function editor_false()
{
    output.innerHTML != editor.innerText;    
}

auto_save.onclick = function()
{
    auto_save_onclick = 0;    
    if(auto_save_onclick == 0){
        auto_save_img.src = 'none auto save.png';
        editor.onkeyup = editor_true; 
        console.log(auto_save_onclick);
    }
}